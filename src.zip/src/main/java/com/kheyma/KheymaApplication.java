package com.kheyma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KheymaApplication {
    public static void main(String[] args) {
        SpringApplication.run(KheymaApplication.class, args);
    }
}

